/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package segundo_proyect;

/**
 *
 * @author Laura Sabillon
 */
public class Tweet_Manager {
    private Tweets[] timeline;
    private users userDatabase; 
    private int tweetCount;

    public Tweet_Manager(int size, users userDatabase) {
        timeline = new Tweets[size];
        this.userDatabase = userDatabase;
        tweetCount = 0;
    }
    
    public void postTweet(String contenido, users user) {
        if (tweetCount < timeline.length) {
            Tweets newTweet = new Tweets(contenido, user);
            timeline[tweetCount] = newTweet;
            tweetCount++;
        }
    }   

    public String Timeline(USUARIO currentUser) {
        String contenido = "";

        for (int index = tweetCount - 1; index >= 0; index--) {
            String creador = timeline[index].getCreador();
            USUARIO creadorUsuario = userDatabase.buscar(creador);

            if (creadorUsuario != null && creadorUsuario.getEstado() && (creador.equals(currentUser.getUsuario()) || currentUser.Siguiendo(creador))) {
                contenido += timeline[index].post() + "\n";
            }
        }
        return contenido;
    }

    public String getMention(users currentUser) {
        String mentions = "";
        for (int index = tweetCount - 1; index >= 0; index--) {
            Tweets tweet = timeline[index];
            String tweetUsername = tweet.getCreador();
            USUARIO tweetUser = userDatabase.buscar(tweetUsername);

            if (tweetUser != null && tweetUser.getEstado() && tweet.interracion(currentUser)) {
                mentions += tweet.post() + "\n";
            }
        }
        return mentions;
    }

    public String getHashtag(String hashtag) {
        String HashTwit = "";

        for (int index = 0; index < tweetCount; index++) {
            Tweets tweet = timeline[index];
            String tweetCreator = tweet.getCreador();
            USUARIO tweetUser = userDatabase.buscar(tweetCreator); 

            if (tweet != null && tweet.containsHashtag(hashtag) && tweetUser != null && tweetUser.getEstado()) {
                HashTwit += tweet.post() + "\n";
            }
        }
        return HashTwit;
    }

    public String TimelineUser(users currentUser, USUARIO otherUser, boolean loggedIn) {
        String contenido = "";
        String usuario = loggedIn ? currentUser.getUsernameInSession() : otherUser.getUsuario();

        if (usuario != null) {
            for (int index = tweetCount - 1; index >= 0; index--) {
                Tweets tweet = timeline[index];
                String tweetCreator = tweet.getCreador();
                USUARIO tweetUser = userDatabase.buscar(usuario); 

                if (tweetCreator.equals(usuario) && tweetUser != null && tweetUser.getEstado()) {
                    contenido += tweet.post() + "\n";
                }
            }
            return contenido;
        }
        return null;
    }
}